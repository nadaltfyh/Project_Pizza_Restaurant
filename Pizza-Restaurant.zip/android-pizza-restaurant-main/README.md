# **Android Pizza Restaurant**
## by Faizal Ramadhan - 1207050034 - PPAM B
![Frame 5](https://user-images.githubusercontent.com/69755016/209740085-306a7f44-b81e-4250-acf1-549aba1eb84f.png)
